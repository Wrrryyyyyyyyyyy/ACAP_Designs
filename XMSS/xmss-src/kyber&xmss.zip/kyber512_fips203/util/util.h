#ifndef RISCV_UTILS
#define RISCV_UTILS

uint64_t riscvcycles(void);
uint64_t riscvinsts(void);


#endif
