#ifndef MURAX_CORE
#define MURAX_CORE

uint64_t cpucycles(void);
void init_uart();

#endif