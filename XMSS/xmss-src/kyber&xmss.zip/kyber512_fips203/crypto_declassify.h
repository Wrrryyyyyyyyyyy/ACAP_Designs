#ifndef PQCLEAN_CRYPTO_DECLASSIFY
#define PQCLEAN_CRYPTO_DECLASSIFY

/* EMPTY MACRO DEFINITION */
#define crypto_declassify(x, y)

#endif
